<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="smc.css" />
    <script src="https://kit.fontawesome.com/824b74e540.js" crossorigin="anonymous"></script>
</head>
<body onload="setTimeout('delayedRedirect()', 5000)">
<div class="nav">
    <header>
        <div class="logo">
            <img src="SMC logo -09-01 095303.png" alt="Logo"> 
        </div>
        <div class="heading">
            <h2>Social Media Campaign</h2>
        </div>        
        <div class="hamburger" onclick="toggleMenu()">
            &#9776; 
        </div>
       <nav>
            <ul class="nav-menu" id="nav-menu">
                <li><a href="home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">About Us</a>
                    <ul class="dropdown-content">
                        <li><a href="info.php">About Us</a></li>
                        <li><a href="contactUs.php">Contact Us</a></li>
                        <li><a href="privacy policy.php">Privacy Policy</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">Our Services</a>
                    <ul class="dropdown-content">
                        <li><a href="staysafe.php">Stay Safe</a></li>
                        <li><a href="tipsforparents.php">Tips For Parents</a></li>
                        <li><a href="livestreaming.php">Safe Livestreaming</a></li>
                        <li><a href="LegislationandGuidance.php">Legislation & Guidance</a></li>
                    </ul>
                </li>
                <li><a href="logins.php">Become a Member</a></li>
            </ul>
        </nav>
    </header>
</div>
<main>
<div class="formreg">
    <h1>Registeration</h1><br>
    <form action="http://localhost/conn/registration.php" method="post">
        <div class="input-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" placeholder="Enter Username" required>
        </div>
        <div class="input-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Enter Email" required>
        </div>
        <div class="input-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter Password" required>
        </div><br>
        <button class="s" type="submit" name="submit">Register</button>
    </form><br>
        <a href="logins.php" class="register-button">Login</a>
    </p>    
</div>
</main>
</body>
<div class="footer">
<footer>
    <div class="footer-content">
        
        <div class="current-page">
            You are here: Registration
        </div>
        
        <div class="copyright">
            &copy; 2024 SMC. All Rights Reserved.
        </div>

        <div class="social-media">
            <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        </div>
    </div>
</footer>
</div>
</html>
<script>
    function toggleMenu() {
        let navMenu = document.getElementById('nav-menu');
        navMenu.classList.toggle('open');
    }
    </script>
