<?php
$conn = new mysqli(
"sql311.infinityfree.com", 
"if0_40553681",      
"oTk0JOjx59T",           
"if0_40553681_register"
);  
$q = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$sql = "SELECT * FROM apps WHERE name LIKE '%$q%' OR technique LIKE '%$q%'";
$res = $conn->query($sql);
if ($res && $res->num_rows){
  echo "<ul class='results-list'>";
  while($r = $res->fetch_assoc()){
    echo "<li><strong>".htmlspecialchars($r['name'])."</strong><p>".htmlspecialchars($r['technique'])."</p></li>";
  }
  echo "</ul>";
}else{
  echo "<p>No results found for <b>".htmlspecialchars($q)."</b>.</p>";
}
$conn->close();
?>
