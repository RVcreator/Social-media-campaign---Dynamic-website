<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="smc.css" />
    <script src="https://kit.fontawesome.com/824b74e540.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

</head>
<body>
<div class="nav">
    <header>
        <div class="logo">
            <img src="SMC logo -09-01 095303.png" alt="Logo"> 
        </div>
        <div class="heading">
            <h2>Social Media Campaign</h2>
        </div>        
        <div class="hamburger" onclick="toggleMenu()">
            &#9776;
        </div>
        <nav>
            <ul class="nav-menu" id="nav-menu">
                <li><a href="home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">About Us</a>
                    <ul class="dropdown-content">
                        <li><a href="info.php">About Us</a></li>
                        <li><a href="contactUs.php">Contact Us</a></li>
                        <li><a href="privacy policy.php">Privacy Policy</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">Our Services</a>
                    <ul class="dropdown-content">
                        <li><a href="staysafe.php">Stay Safe</a></li>
                        <li><a href="tipsforparents.php">Tips For Parents</a></li>
                        <li><a href="livestreaming.php">Safe Livestreaming</a></li>
                        <li><a href="LegislationandGuidance.php">Legislation & Guidance</a></li>
                    </ul>
                </li>
                <li><a href="logins.php">Become a Member</a></li>
            </ul>
        </nav>
    </header>
</div>

<main>
    <h2>To gain access to our monthly newspaper Subscribe now!!</h2><br>
    <div class="formreg">
        <h1> SUBSCRIBE </h1><br>
        <form action="https://social-media-account.ct.ws/login.php" method="post">
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Enter Username" required>
            </div>
            
            <div class="input-group">
                <label for="password"> Email</label>
                <input type="email" id="email" name="email" placeholder="Enter Your Email" required>
            </div><br>
            <button class="s" type="submit" name="submit"> Subscribe </button>
        </form><br>
          
    </div>
   <button class="delete-button" onclick="openUnsubscribePopup()">Unsubscribe</button>


    <div id="subscribePopup" style="display:none;">
    <div class="popup-content">
        <button type="button" class="popup-close" onclick="closeSubscribePopup()">×</button>
        <h2>Congratulations!🎉</h2><br>
        <p>You have now subscribed.<br> Make sure to check your inbox for regular updates.</p>
    </div>
</div>

<div id="unsubscribePopup" style="display:none;" class="modal">
    <div class="popup-content">
        <button type="button" class="popup-close" onclick="closeUnsubscribePopup()">×</button>
        <h2>Unsubscribe</h2>
        <p>Please enter your details to unsubscribe:</p>

        <form id="unsubscribeForm">
            <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" required>
            </div>

            <div class="input-group">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>
<br>
            <button type="submit" class="delete-button">Confirm Unsubscribe</button>
        </form>

        <p id="unsubscribeMessage" style="color: green; display:none; margin-top:10px;"></p>
    </div>
</div>


</main><br>

<footer>
    <div class="footer-content">
        <div class="current-page">You are here: Subscribe</div>
        <div class="copyright">&copy; 2024 SMC. All Rights Reserved.</div>
        <div class="social-media">
            <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        </div>
    </div>
</footer>

<script>
function toggleMenu() {
    let navMenu = document.getElementById('nav-menu');
    navMenu.classList.toggle('open');
}
</script>
<script>
const form = document.querySelector('form');

form.addEventListener('submit', function(e) {
    e.preventDefault(); // stop normal submission

    // Collect form data
    const formData = new FormData(form);

    // Send data to backend using fetch
    fetch(form.action, {
        method: form.method,
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        // Optionally: check response from PHP
        showSubscribePopup();
        form.reset(); // reset the form
    })
    .catch(err => {
        alert('There was an error. Please try again.');
        console.error(err);
    });
});

function showSubscribePopup() {
    const popup = document.getElementById('subscribePopup');
    popup.style.display = 'flex';
}

function closeSubscribePopup() {
    const popup = document.getElementById('subscribePopup');
    popup.style.display = 'none';
}

document.getElementById('subscribePopup').addEventListener('click', function(ev){
    if(ev.target === this) closeSubscribePopup();
});

// Show unsubscribe popup
function openUnsubscribePopup() {
    document.getElementById('unsubscribePopup').style.display = 'flex';
}

// Close unsubscribe popup
function closeUnsubscribePopup() {
    document.getElementById('unsubscribePopup').style.display = 'none';
}

// Close when clicking outside
document.getElementById('unsubscribePopup').addEventListener('click', function(e){
    if (e.target === this) closeUnsubscribePopup();
});

// Handle unsubscribe form submit
document.getElementById('unsubscribeForm').addEventListener('submit', function(e){
    e.preventDefault();

    const formData = new FormData(this);

    fetch("https://social-media-account.ct.ws/delete.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        document.getElementById('unsubscribeMessage').innerText = data;
        document.getElementById('unsubscribeMessage').style.display = "block";
        this.reset();
    })
    .catch(err => alert("Error unsubscribing."));

    function showUnsubscribePopup() {
    const popup = document.getElementById('unsubscribePopup');
    popup.style.display = 'flex';

    // blur the whole page
    document.body.style.filter = "blur(4px)";
}


function closeUnsubscribePopup() {
    const popup = document.getElementById('unsubscribePopup');
    popup.style.display = 'none';

    // remove blur
    document.body.style.filter = "none";
}

});
</script>
</body>
</html>