<?php
$db1_host = "sql311.infinityfree.com";
$db1_user = "if0_40553681";
$db1_pass = "oTk0JOjx59T";
$db1_name = "if0_40553681_register";

$con = new mysqli($db1_host, $db1_user, $db1_pass, $db1_name);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}
?>
