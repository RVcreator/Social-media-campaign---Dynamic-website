<?php
require('db_connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get username and email from POST
    $name = mysqli_real_escape_string($con, $_POST['username']);
    $email = mysqli_real_escape_string($con, $_POST['email']);

    if ($name && $email) {
        
        // Delete the matching subscriber
        $query = "DELETE FROM new_users WHERE name='$name' AND email='$email'";
        $result = mysqli_query($con, $query);

        if (mysqli_affected_rows($con) > 0) {
            echo json_encode(['status' => 'success', 'message' => 'You have unsubscribed successfully.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No matching user found.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Missing username or email.']);
    }
}
?>
