<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require('db_connect.php');  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name  = isset($_POST['username']) ? mysqli_real_escape_string($con, $_POST['username']) : '';
    $email = isset($_POST['email']) ? mysqli_real_escape_string($con, $_POST['email']) : '';

    if ($name && $email) {

        $query = "SELECT * FROM new_users WHERE name='$name' AND email='$email'";
        $result = mysqli_query($con, $query);

        if (!$result) {
            die("Query error: " . mysqli_error($con));
        }

        if (mysqli_num_rows($result) === 0) {
            $insert = "INSERT INTO new_users (name, email) VALUES ('$name', '$email')";
            if (!mysqli_query($con, $insert)) {
                die("Insert error: " . mysqli_error($con));
            }
        }

        echo "success";
    } else {
        echo "Missing name or email.";
    }

    exit();
}
?>
