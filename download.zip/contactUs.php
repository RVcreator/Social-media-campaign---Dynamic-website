<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Contact Us</title>
    <link rel="stylesheet" href="smc.css"> 
    <script src="https://kit.fontawesome.com/824b74e540.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>
    <div class="nav">
    <header>
        <div class="logo">
            <img src="SMC logo -09-01 095303.png" alt="Logo"> 
        </div>
        <div class="heading">
            <h2>Social Media Campaign</h2>
           
        </div>        
        <div class="hamburger" onclick="toggleMenu()">
            &#9776; 
        </div>
        <nav>
            <ul class="nav-menu" id="nav-menu">
                <li><a href="home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">About Us</a>
                    <ul class="dropdown-content">
                        <li><a href="info.php">About Us</a></li>
                        <li><a href="contactUs.php">Contact Us</a></li>
                        <li><a href="privacy policy.php">Privacy Policy</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">Our Services</a>
                    <ul class="dropdown-content">
                        <li><a href="staysafe.php">Stay Safe</a></li>
                        <li><a href="tipsforparents.php">Tips For Parents</a></li>
                        <li><a href="livestreaming.php">Safe Livestreaming</a></li>
                        <li><a href="LegislationandGuidance.php">Legislation & Guidance</a></li>
                    </ul>
                </li>
                <li><a href="logins.php">Become a Member</a></li>
            </ul>
        </nav>
    </header>
    </div>

    <main>
        <section class="contact-info">
            <h2>Get in Touch</h2>
            <p>Feel free to reach out to us for any questions, concerns, or feedback. We're here to help!</p>

            
            <div class="details">
                <div class="detail-item">
                    <i class="fas fa-phone"></i>
                    <p><strong>Phone:</strong> +123 456 7890</p>
                </div>
                <div class="detail-item">
                    <i class="fas fa-envelope"></i>
                    <p><strong>Email:</strong> contact@smc.com</p>
                </div>
                <div class="detail-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <p><strong>Address:</strong> 123 Social Media St, Web City, WC 4567</p>
                </div>
            </div>
        </section>

       
        <section class="contact-form">
           <form id="contactForm" method="post">
    <h2>Send Us a Message</h2>
    <label for="name">Your Name</label>
    <input type="text" id="name" name="name" required>

    <label for="email">Your Email</label>
    <input type="email" id="email" name="email" required>

    <label for="message">Your Message</label>
    <textarea id="message" name="message" rows="5" required></textarea>

    <button type="submit">Send Message</button>
</form>

        </section>
    </main>
<script>
document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault(); // prevent default form submission

    // collect form data
    const formData = new FormData(this);

    fetch('smc_formsubmission.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        // show popup
        alert('Message sent successfully!');
        // optionally, reset the form
        document.getElementById('contactForm').reset();
    })
    .catch(error => {
        alert('There was an error sending your message.');
        console.error(error);
    });
});
</script>


    

<div class="footer">
<footer>
    <div class="footer-content">
        
        <div class="current-page">
            You are here: Contact Us
        </div>

        
        <div class="copyright">
            &copy; 2024 SMC. All Rights Reserved.
        </div>

        
        <div class="social-media">
            <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        </div>
    </div>
</footer>
</div>
</body>
</html>

    <script>
function toggleMenu() {
    let navMenu = document.getElementById('nav-menu');
    navMenu.style.display =
        navMenu.style.display === "block" ? "none" : "block";
}
</script>


