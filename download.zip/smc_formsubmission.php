<?php
$db1_host = "sql311.infinityfree.com";
$db1_user = "if0_40553681";
$db1_pass = "oTk0JOjx59T";
$db1_name = "if0_40553681_register";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';

    // Connect to database
    $conn = new mysqli($db1_host, $db1_user, $db1_pass, $db1_name);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $message);

    if($stmt->execute()){
        echo "success"; // JS will see this
    } else {
        echo "error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

} else {
    echo "error";
}
?>
