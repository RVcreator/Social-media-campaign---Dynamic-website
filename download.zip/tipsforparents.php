<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How Parents Can Help - Social Media Safety</title>
    <link rel="stylesheet" href="smc.css">
    <script src="https://kit.fontawesome.com/824b74e540.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="nav">
    <header>
        <div class="logo">
            <img src="SMC logo -09-01 095303.png" alt="Logo">
        </div>
        <div class="heading">
            <h2>Social Media Campaign</h2>
        </div>        
        <div class="hamburger" onclick="toggleMenu()">&#9776;</div>
       
        <nav>
            <ul class="nav-menu" id="nav-menu">
                <li><a href="home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">About Us</a>
                    <ul class="dropdown-content">
                        <li><a href="info.php">About Us</a></li>
                        <li><a href="contactUs.php">Contact Us</a></li>
                        <li><a href="privacy policy.php">Privacy Policy</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">Our Services</a>
                    <ul class="dropdown-content">
                        <li><a href="staysafe.php">Stay Safe</a></li>
                        <li><a href="tipsforparents.php">Tips For Parents</a></li>
                        <li><a href="livestreaming.php">Safe Livestreaming</a></li>
                        <li><a href="LegislationandGuidance.php">Legislation & Guidance</a></li>
                    </ul>
                </li>
                <li><a href="logins.php">Become a Member</a></li>
            </ul>
        </nav>
    </header>
</div>

    <main>
        <section class="tips-for-parents">
            <h1>How Parents Can Help:<br> Supporting Healthy Social Media Use</h1><br>
            <p>Social media can have both positive and negative effects on teens. As a parent, you can play an important role in guiding your teens towards healthy and responsible use of social media platforms. Here are some tips to help:</p><br>

            <div class="tip-box">
                <h2>1. Communicate Openly About Social Media</h2><br>
                <p>Encourage open dialogue with your teen about their social media use. Ask them about their favorite platforms, what they like about them, and if there are any issues they face.</p>
            </div>

            <div class="tip-box">
                <h2>2. Set Time Limits</h2><br>
                <p>Help your teen manage their time by setting limits on how much time they spend on social media each day. This prevents excessive use and helps them balance online and offline activities.</p>
            </div>

            <div class="tip-box">
                <h2>3. Teach Critical Thinking</h2><br>
                <p>Encourage your teen to question the information they come across on social media. Help them understand the importance of fact-checking and recognizing misinformation or harmful content.</p>
            </div>

            <div class="tip-box">
                <h2>4. Monitor Their Online Activity</h2><br>
                <p>While respecting their privacy, it's important to stay aware of what your teen is doing online. Use parental controls and monitor their behavior to ensure their safety.</p>
            </div>

            <div class="tip-box">
                <h2>5. Promote Healthy Social Media Habits</h2><br>
                <p>Encourage your teen to use social media in a positive way. They can connect with friends, join educational groups, and participate in communities that promote learning and personal growth.</p>
            </div>

            <div class="tip-box">
                <h2>6. Be a Role Model</h2><br>
                <p>Demonstrate healthy social media habits yourself. Limit your own screen time and engage in meaningful interactions both online and offline to set a good example.</p>
            </div>

            <div class="tip-box">
                <h2>7. Address Cyberbullying</h2><br>
                <p>If your teen faces any form of online harassment or cyberbullying, address the issue immediately. Support them emotionally, and teach them how to block and report inappropriate behavior.</p>
            </div>

            <div class="tip-box">
                <h2>8. Balance Online and Offline Activities</h2><br>
                <p>Encourage your teen to participate in offline activities, such as sports, hobbies, or spending time with family. Maintaining a balance between online and real-world interactions is key to their well-being.</p>
            </div>
        </section>
    </main>

    <div class="footer">
    <footer>
        <div class="footer-content">
            <div class="current-page">
                You are here: How Parents Can Help
            </div>
            <div class="copyright">
                &copy; 2024 SMC. All Rights Reserved.
            </div>
            <div class="social-media">
                <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
            </div>
        </div>
    
    </footer>
    </div>
    

    <script>
        function toggleMenu() {
            var navMenu = document.getElementById("nav-menu");
            if (navMenu.style.display === "block") {
                navMenu.style.display = "none";
            } else {
                navMenu.style.display = "block";
            }
        }
    </script>
</body>
</html>
