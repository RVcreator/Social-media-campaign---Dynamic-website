<!DOCTYPE html>
<html>
<head>
    <title>Login Form</title>
    <style>
        .speed {
            padding: 150px;
        }
    </style>
</head>
<body>
    <form action="insert.php" method="post">
        <table align="center" class="speed">
            <tr>
                <td>First Name:</td>
                <td><input type="text" name="first_name" placeholder="Please enter your first name"></td>
            </tr>
            <tr>
                <td>Last Name:</td>
                <td><input type="text" name="last_name" placeholder="Please enter your last name"></td>
            </tr>
            <tr>
                <td>City Name:</td>
                <td><input type="text" name="city_name" placeholder="Please enter your city name"></td>
            </tr>
            <tr>
                <td>E-mail:</td>
                <td><input type="text" name="email" placeholder="Please enter your email"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="submit" value="Submit"></td>
            </tr>
        </table>

        <div style= align = "center">
            <button type="button" onclick="window.location.href='retrive.php';">Retrive</button>
 
