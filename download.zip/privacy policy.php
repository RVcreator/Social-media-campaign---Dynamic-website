<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Privacy Policy</title>
    <link rel="stylesheet" type="text/css" href="smc.css">
    <script src="https://kit.fontawesome.com/824b74e540.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>
    <div class="nav">
    <header>
        <div class="logo">
            <img src="SMC logo -09-01 095303.png" alt="Logo"> 
        </div>
        <div class="heading">
            <h2>Social Media Campaign</h2>
            
        </div>        
        <div class="hamburger" onclick="toggleMenu()">
            &#9776; 
        </div>
        <nav>
            <ul class="nav-menu" id="nav-menu">
                <li><a href="home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">About Us</a>
                    <ul class="dropdown-content">
                        <li><a href="info.php">About Us</a></li>
                        <li><a href="contactUs.php">Contact Us</a></li>
                        <li><a href="privacy policy.php">Privacy Policy</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">Our Services</a>
                    <ul class="dropdown-content">
                        <li><a href="staysafe.php">Stay Safe</a></li>
                        <li><a href="tipsforparents.php">Tips For Parents</a></li>
                        <li><a href="livestreaming.php">Safe Livestreaming</a></li>
                        <li><a href="LegislationandGuidance.php">Legislation & Guidance</a></li>
                    </ul>
                </li>
                <li><a href="logins.php">Become a Member</a></li>
            </ul>
        </nav>
    </header>
</div>
    
    <main>
        <section class="privacy-policy">
            <h1>Privacy Policy</h1>
            <p>At Social Media Campaign, we are committed to protecting your privacy and ensuring that your personal information is handled in a safe and responsible manner.</p>

            <h2>Information We Collect</h2>
            <p>We collect personal information when you provide it to us, such as when you fill out a contact form or subscribe to our newsletter. This information may include your name, email address, and any other details you provide.</p>


            <h2>Cookies</h2>
            <p>We use cookies to improve your experience on our website. A cookie is a small text file that is placed on your device. You can disable cookies in your browser settings if you prefer.</p>

            <h2>Third-Party Links</h2>
            <p>Our website may contain links to other websites. We are not responsible for the privacy practices or the content of these external sites.</p>

            <h2>Data Security</h2>
            <p>We take appropriate measures to ensure that your personal information is protected from unauthorized access, use, or disclosure.</p>

            <h2>Your Consent</h2>
            <p>By using our website, you consent to the collection and use of your information as outlined in this Privacy Policy.</p>

            <h2>Changes to Our Privacy Policy</h2>
            <p>We may update this Privacy Policy from time to time. Any changes will be posted on this page, and the date at the top will be updated accordingly.</p>

            <h2>Contact Us</h2>
            <p>If you have any questions about this Privacy Policy, please contact us at:</p>
            <p>Email: <a href="mailto:contact@smc.com">contact@smc.com</a></p>
            <p>Phone: +123 456 7890</p>
        </section>
    </main>
</body>
<div class="footer">
<footer>
    <div class="footer-content">
        
        <div class="current-page">
            You are here: Home Page
        </div>

        
        <div class="copyright">
            &copy; 2024 SMC. All Rights Reserved.
        </div>

        
        <div class="social-media">
            <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        </div>
    </div>
</footer>
</div>
</html>
<script>
    function toggleMenu() {
    let navMenu = document.getElementById('nav-menu');
    navMenu.classList.toggle('open');
}
</script>