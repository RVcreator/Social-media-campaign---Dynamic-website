<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Legislation & Guidance - Social Media Safety</title>
    <link rel="stylesheet" href="smc.css">
    <script src="https://kit.fontawesome.com/824b74e540.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="nav">
    <header>
        <div class="logo">
            <img src="SMC logo -09-01 095303.png" alt="Logo">
        </div>
        <div class="heading">
            <h2>Social Media Campaign</h2>
           
        </div>        
        <div class="hamburger" onclick="toggleMenu()">&#9776;</div>
        <nav>
            <ul class="nav-menu" id="nav-menu">
                <li><a href="home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">About Us</a>
                    <ul class="dropdown-content">
                        <li><a href="info.php">About Us</a></li>
                        <li><a href="contactUs.php">Contact Us</a></li>
                        <li><a href="privacy policy.php">Privacy Policy</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">Our Services</a>
                    <ul class="dropdown-content">
                        <li><a href="staysafe.php">Stay Safe</a></li>
                        <li><a href="tipsforparents.php">Tips For Parents</a></li>
                        <li><a href="livestreaming.php">Safe Livestreaming</a></li>
                        <li><a href="LegislationandGuidance.php">Legislation & Guidance</a></li>
                    </ul>
                </li>
                <li><a href="logins.php">Become a Member</a></li>
            </ul>
        </nav>
    </header>
</div>

    <main>
        <section class="legislation-guidance">
            <h1>Legislation & Best Practice Guidance</h1><br>
            <p>The landscape of social media is evolving rapidly, and it is critical to stay informed about the relevant legislation and best practice guidelines to ensure a safe and secure online environment for everyone. Below are key regulations and guidance for safe social media use.</p><br>

            <h2>Key Legislation</h2><br>
            <p>Several laws have been enacted to ensure the safety of users online, particularly when it comes to social media platforms. Understanding these laws can help protect individuals, especially younger users.</p><br>

            <div class="legislation-box">
                <h3>1. General Data Protection Regulation (GDPR)</h3><br>
                <p>The GDPR is a comprehensive data protection law that applies to all organizations that collect and process the personal data of EU residents. It mandates strict guidelines on how personal information is collected, stored, and shared, giving users more control over their data.</p>
            </div><br>

            <div class="legislation-box">
                <h3>2. Children's Online Privacy Protection Act (COPPA)</h3><br>
                <p>COPPA is a U.S. law designed to protect the online privacy of children under 13 years of age. Social media platforms must obtain parental consent before collecting personal information from children and must also provide transparent privacy policies.</p>
            </div><br>

            <div class="legislation-box">
                <h3>3. Communications Decency Act (CDA) Section 230</h3><br>
                <p>This U.S. law provides immunity to online platforms from liability for content posted by users, while also giving them the authority to moderate and remove harmful or inappropriate content.</p>
            </div><br>

            <div class="legislation-box">
                <h3>4. Digital Economy Act (UK)</h3><br>
                <p>This legislation requires age verification for users accessing certain types of content online, aiming to protect minors from exposure to harmful material on the internet.</p><br>
            </div><br>

            <h2>Best Practice Guidance</h2><br>
            <p>In addition to legal requirements, adopting best practices in social media use is essential for maintaining a safe and healthy digital environment.</p>

            <div class="guidance-box">
                <h3>1. Practice Digital Civility</h3><br>
                <p>Users should always be respectful and mindful of others when interacting online. Digital civility includes refraining from cyberbullying, avoiding hate speech, and supporting positive and meaningful interactions.</p>
            </div>

            <div class="guidance-box">
                <h3>2. Educate Yourself on Privacy Settings</h3><br>
                <p>Make sure you understand how to adjust privacy settings on social media platforms to control who can see your content, who can interact with you, and what information is publicly available.</p>
            </div>

            <div class="guidance-box">
                <h3>3. Report Inappropriate Content</h3><br>
                <p>Social media platforms often provide tools to report content that violates community guidelines. Make use of these features to help maintain a safe online space for everyone.</p>
            </div>

            <div class="guidance-box">
                <h3>4. Limit Screen Time</h3><br>
                <p>Excessive use of social media can lead to burnout and mental health issues. Setting limits on screen time ensures a balanced lifestyle and prevents overexposure to harmful content.</p>
            </div>
        </section>
    </main>

    <div class="footer">
    <footer>
        <div class="footer-content">
            <div class="current-page">
                You are here: Legislation & Guidance
            </div>
            <div class="copyright">
                &copy; 2024 SMC. All Rights Reserved.
            </div>
            <div class="social-media">
                <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
            </div>
        </div>
    </footer>
</div>

    <script>
        function toggleMenu() {
            var navMenu = document.getElementById("nav-menu");
            if (navMenu.style.display === "block") {
                navMenu.style.display = "none";
            } else {
                navMenu.style.display = "block";
            }
        }
    </script>
</body>
</html>
