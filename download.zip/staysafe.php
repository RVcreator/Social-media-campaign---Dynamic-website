<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stay Safe</title>
    <link rel="stylesheet" href="smc.css">
    <script src="https://kit.fontawesome.com/824b74e540.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<body>

<div class="nav">
<header>
    <div class="logo">
        <img src="SMC logo -09-01 095303.png" alt="Logo">
    </div>

    <div class="heading">
        <h2>Social Media Campaign</h2>
    </div>

    <div class="hamburger" onclick="toggleMenu()">&#9776;</div>

    <nav>
        <ul class="nav-menu" id="nav-menu">
            <li><a href="home.php">Home</a></li>

            <li class="dropdown">
                <a href="#" class="dropbtn">About Us</a>
                <ul class="dropdown-content">
                    <li><a href="info.php">About Us</a></li>
                    <li><a href="contactUs.php">Contact Us</a></li>
                    <li><a href="privacy policy.php">Privacy Policy</a></li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#" class="dropbtn">Our Services</a>
                <ul class="dropdown-content">
                    <li><a href="staysafe.php">Stay Safe</a></li>
                    <li><a href="tipsforparents.php">Tips For Parents</a></li>
                    <li><a href="livestreaming.php">Safe Livestreaming</a></li>
                    <li><a href="LegislationandGuidance.php">Legislation & Guidance</a></li>
                </ul>
            </li>

            <li><a href="logins.php">Become a Member</a></li>
        </ul>
    </nav>
</header>
</div>

<main>

    <section class="popular-apps">
        <h1>Most Popular Social Media Apps</h1><br>
        <p>Search our database for the latest safety tips and techniques.</p>

       
        <form id="searchForm">
            <label for="search">Search apps or techniques:</label>
            <input type="text" id="search" name="search" placeholder="Enter app name" required>
            <button type="submit">Search</button>
        </form>
    </section>

    <section class="app-list">
        <h2>Popular Social Media Apps</h2><br>
        <ul>
            <li><i class="fab fa-instagram"></i> Instagram</li>
            <li><i class="fab fa-tiktok"></i> TikTok</li>
            <li><i class="fab fa-facebook-f"></i> Facebook</li>
            <li><i class="fab fa-twitter"></i> Twitter</li>
            <li><i class="fab fa-snapchat"></i> Snapchat</li>
            <li><i class="fab fa-youtube"></i> YouTube</li>
            <li><i class="fab fa-whatsapp"></i> WhatsApp</li>
        </ul>
    </section>

</main>


<div id="resultsPopup" aria-hidden="true" style="display:none";>
  <div class="popup-content">
    <button type="button" class="popup-close" onclick="closePopup()">×</button>
    <div id="popupResults" role="region" aria-live="polite"></div>
  </div>
</div>

<script>

(function(){
  const form = document.getElementById('searchForm');
  if (!form) return; // if your page has no searchForm, do nothing

  form.addEventListener('submit', function(e){
    e.preventDefault();

    const q = (document.getElementById('search') || {}).value || '';
    if (!q.trim()) return;

    // fetch backend (existing search_results.php) and put result into popup
    const url = 'search_results.php?search=' + encodeURIComponent(q);
    fetch(url, { method: 'GET' })
      .then(resp => resp.text())
      .then(html => {
        document.getElementById('popupResults').innerHTML = html;
        document.getElementById('resultsPopup').style.display = 'flex';
        document.getElementById('resultsPopup').setAttribute('aria-hidden','false');
      })
      .catch(err => {
        document.getElementById('popupResults').innerHTML = '<p>There was an error. Try again.</p>';
        document.getElementById('resultsPopup').style.display = 'flex';
      });
  });

 
  document.getElementById('resultsPopup').addEventListener('click', function(ev){
    if (ev.target === this) closePopup();
  });

  window.closePopup = function(){
    document.getElementById('resultsPopup').style.display = 'none';
    document.getElementById('resultsPopup').setAttribute('aria-hidden','true');
    document.getElementById('popupResults').innerHTML = '';
  };
})();
</script>

</body>

<div class="footer"></div>
<footer>
    <div class="footer-content">
        <div class="current-page">You are here: Stay Safe</div>

        <div class="copyright">
            &copy; 2024 SMC. All Rights Reserved.
        </div>

        <div class="social-media">
            <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        </div>
    </div>
</footer>
</html>
