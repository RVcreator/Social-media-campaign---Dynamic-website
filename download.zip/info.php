<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>information</title>
    <link rel="stylesheet" type="text/css" href="smc.css">
    <script src="https://kit.fontawesome.com/824b74e540.js" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>
    <div class="nav">
    <header>
        <div class="logo">
            <img src="SMC logo -09-01 095303.png" alt="Logo"> 
        </div>
        <div class="heading">
            <h2>Social Media Campaign</h2>
        </div>        
        <div class="hamburger" onclick="toggleMenu()">
            &#9776; 
        </div>
        <nav>
            <ul class="nav-menu" id="nav-menu">
                <li><a href="home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">About Us</a>
                    <ul class="dropdown-content">
                        <li><a href="info.php">About Us</a></li>
                        <li><a href="contactUs.php">Contact Us</a></li>
                        <li><a href="privacy policy.php">Privacy Policy</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">Our Services</a>
                    <ul class="dropdown-content">
                        <li><a href="staysafe.php">Stay Safe</a></li>
                        <li><a href="tipsforparents.php">Tips For Parents</a></li>
                        <li><a href="livestreaming.php">Safe Livestreaming</a></li>
                        <li><a href="LegislationandGuidance.php">Legislation & Guidance</a></li>
                    </ul>
                </li>
                <li><a href="logins.php">Become a Member</a></li>
            </ul>
        </nav>
    </header>
</div>
    <main>
       
        <section class="intro">
            <h2>About Us</h2>
            <p>
             Welcome to Social Media Campaign, a platform dedicated to helping people stay safe online and raise awareness about responsible social media usage. Our goal is to provide tips, advice, and resources for both parents and children to navigate the online world safely.
            </p>
        </section>

        <section class="mission">
            <h2>Our Mission</h2>
            <p>
             Our mission is to create a safer digital space for everyone. We work hard to spread awareness about internet safety and empower users with the knowledge to protect themselves from online risks. Whether it’s educating kids about cyberbullying or guiding parents on how to keep their children safe, we’re here to support you.
            </p>
        </section>

        <section class="team">
            <h2>Meet Our Team</h2>
            <div class="team-members">
                <div class="team-member">
                    <img src="pexels-linkedin-2182970.jpg" alt="Team Member 1">
                    <h3>Mohammed Ali</h3>
                    <p>CEO & Founder</p>
                </div>
                <div class="team-member">
                    <img src="pexels-divinetechygirl-1181690.jpg" alt="Team Member 2">
                    <h3>Diana lee</h3>
                    <p>Chief Technology Officer</p>
                </div>
                <div class="team-member">
                    <img src="pexels-cottonbro-3206114.jpg" alt="Team Member 3">
                    <h3>Big ben</h3>
                    <p>Head of Marketing</p>
                </div>
            </div>
        </section>
    </main>
<div class="footer">
<footer>
    <div class="footer-content">
        
        <div class="current-page">
            You are here: About Us Page
        </div>

        
        <div class="copyright">
            &copy; 2024 SMC. All Rights Reserved.
        </div>

        <div class="social-media">
            <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
        </div>
    </div>
</footer>
</div>
                <script>
    function toggleMenu() {
        let navMenu = document.getElementById('nav-menu');
        navMenu.classList.toggle('open');
    }
</script>

                </body>
</html>
