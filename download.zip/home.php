<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Home Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" type="text/css" href="smc.css">
    <script src="https://kit.fontawesome.com/824b74e540.js" crossorigin="anonymous"></script>
</head>
<body>
    <header>
        <div class="logo">
            <img src="SMC logo -09-01 095303.png" alt="Logo"> 
        </div>
        <div class="heading">
            <h2>Social Media Campaign</h2>
        </div>        
        <div class="hamburger" onclick="toggleMenu()">
            &#9776; 
        </div>
        <nav>
            <ul class="nav-menu" id="nav-menu">
                <li><a href="home.php">Home</a></li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">About Us</a>
                    <ul class="dropdown-content">
                        <li><a href="info.php">About Us</a></li>
                        <li><a href="http://localhost/conn/contactUs.php">Contact Us</a></li>
                        <li><a href="privacy policy.php">Privacy Policy</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropbtn">Our Services</a>
                    <ul class="dropdown-content">
                        <li><a href="staysafe.php">Stay Safe</a></li>
                        <li><a href="tipsforparents.php">Tips For Parents</a></li>
                        <li><a href="livestreaming.php">Safe Livestreaming</a></li>
                        <li><a href="LegislationandGuidance.php">Legislation & Guidance</a></li>
                    </ul>
                <li><a href="logins.php">Become a Member</a></li>
            </ul>
        </nav>
    </header>

        <div class="search-container">
            <input type="text" id="searchInput" placeholder="Search..." onkeyup="searchFunction()">
        </div>
        

        <div class="slider-container">
            <div class="slider">
                <div class="slide fade">
                    <img src="pexels-julia-m-cameron-4144099.jpg" alt="Image 1">
                </div>
                <div class="slide fade">
                    <img src="AdobeStock_659899368_Preview.jpeg" alt="Image 2">
                </div>
                <div class="slide fade">
                    <img src="Screenshot 2024-09-09 114453.png" alt="Image 3">
                </div>
            </div>
            <a class="prev" onclick="changeSlide(-1)">&#10094;</a>
            <a class="next" onclick="changeSlide(1)">&#10095;</a>
        </div>
        
        <div class="staysafeonline">
            <h1>How To Stay Safe Online for Teenagers </h1><br>
            
            <p>
                <b>1. Use Strong and Unique Passwords</b><br> <br>
               <li> Make sure your passwords are a mix of uppercase and lowercase alphabets,Unique characters and nunmbers.</li><br>
               <li> Use a different password for each account.</li><br>
               <li> Consider using a password manager for all your passwords.</li><br><br>

               <b>2. Be Cautious with Personal Information</b><br> <br>
               <li> Limit the amount of personal information shared online (e.g, phone numbers, home address).</li><br>
               <li> Review your privacy settings on social media to control who can see your posts.</li><br><br>

               <b>3. Be Careful with Downloads</b><br> <br>
               <li> Only download files and software from trusted sources.</li><br>
               <li> Malicious software can infect your device and steal your data.</li><br><br>

               <b>4. Guard Against Cyberbullying</b><br> <br>
               <li> Be mindful of the tone and content of your posts and interactions.</li><br>
               <li> If you or someone you know experiences cyberbullying, block the person and report the behavior to the platform.</li><br><br>
            </p>
        </div>

        <div class="footer">
        <footer>
            <div class="footer-content">
                
                <div class="current-page">
                    You are here: Home Page
                </div>
    
                
                <div class="copyright">
                    &copy; 2024 SMC. All Rights Reserved.
                </div>
    
                
                <div class="social-media">
                    <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                    <a href="https://www.twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                </div>
            </div>
        </footer>
        </div>
        
</body>
</html>

<script> 
    let slideIndex = 0;
showSlides();


function showSlides() {
    let i;
    let slides = document.getElementsByClassName("slide");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {
        slideIndex = 1;  
    }
    slides[slideIndex - 1].style.display = "block";  
    setTimeout(showSlides, 3000);  
}

function changeSlide(n) {
    let slides = document.getElementsByClassName("slide");
    slideIndex += n;
    if (slideIndex > slides.length) {
        slideIndex = 1;
    }
    if (slideIndex < 1) {
        slideIndex = slides.length;
    }
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slides[slideIndex - 1].style.display = "block";
}

</script>

<script>
    function searchFunction() {
    
    var input = document.getElementById('searchInput');
   
    var filter = input.value.toUpperCase();
    
    var content = document.getElementsByTagName('p');
    
    
    for (var i = 0; i < content.length; i++) {
        var txtValue = content[i].textContent || content[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            content[i].style.display = "";
        } else {
            content[i].style.display = "none";
        }
    }
}

function toggleMenu() {
    let navMenu = document.getElementById('nav-menu');
    navMenu.classList.toggle('open');
}


</script>
